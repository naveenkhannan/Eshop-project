using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System.Collections.Concurrent;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IProductRepository, InMemoryProductRepository>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseSwagger();
app.UseSwaggerUI();

app.MapGet("/", () => Results.Redirect("/swagger"));

app.MapGet("/api/products", (IProductRepository repo) =>
{
    return Results.Ok(repo.GetAll());
});

app.MapGet("/api/products/{id:int}", (int id, IProductRepository repo) =>
{
    var p = repo.Get(id);
    return p is not null ? Results.Ok(p) : Results.NotFound();
});

app.MapPost("/api/products", (Product p, IProductRepository repo) =>
{
    var created = repo.Add(p);
    return Results.Created($"/api/products/{created.Id}", created);
});

app.MapPut("/api/products/{id:int}", (int id, Product update, IProductRepository repo) =>
{
    var updated = repo.Update(id, update);
    return updated is not null ? Results.Ok(updated) : Results.NotFound();
});

app.MapDelete("/api/products/{id:int}", (int id, IProductRepository repo) =>
{
    var removed = repo.Delete(id);
    return removed ? Results.NoContent() : Results.NotFound();
});

app.Run();

public record Product(int Id, string Name, decimal Price);

public interface IProductRepository
{
    IEnumerable<Product> GetAll();
    Product? Get(int id);
    Product Add(Product p);
    Product? Update(int id, Product update);
    bool Delete(int id);
}

public class InMemoryProductRepository : IProductRepository
{
    private readonly ConcurrentDictionary<int, Product> _store = new();
    private int _id = 0;

    public InMemoryProductRepository()
    {
        // seed
        Add(new Product(0, "Sample Product A", 9.99m));
        Add(new Product(0, "Sample Product B", 19.99m));
    }

    public Product Add(Product p)
    {
        var id = System.Threading.Interlocked.Increment(ref _id);
        var prod = p with { Id = id };
        _store[id] = prod;
        return prod;
    }

    public bool Delete(int id) => _store.TryRemove(id, out _);

    public Product? Get(int id) => _store.TryGetValue(id, out var p) ? p : null;

    public IEnumerable<Product> GetAll() => _store.Values.OrderBy(p => p.Id);

    public Product? Update(int id, Product update)
    {
        if (!_store.ContainsKey(id)) return null;
        var prod = update with { Id = id };
        _store[id] = prod;
        return prod;
    }
}
