#!/usr/bin/env bash
# Simple smoke tests using curl (assumes the app is running on localhost:8080)
set -e
echo "Creating product..."
curl -s -X POST -H 'Content-Type: application/json' -d '{"id":0,"name":"Test","price":3.5}' http://localhost:8080/api/products | jq
echo "Listing products..."
curl -s http://localhost:8080/api/products | jq
