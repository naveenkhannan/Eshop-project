# eShop Sample (.NET 7) — Docker, ACR, AKS, Azure Pipelines

This repository contains a tiny ASP.NET Core minimal API (Products) sample, a Dockerfile, Kubernetes manifests,
and an Azure DevOps pipeline file to build, push to Azure Container Registry (ACR), and deploy to AKS.

## Project structure
- eShop/                 : .NET minimal API project
- Dockerfile             : multi-stage Dockerfile
- k8s/deployment.yaml    : Kubernetes Deployment (edit image name)
- k8s/service.yaml       : Kubernetes Service (LoadBalancer)
- azure-pipelines.yml    : Azure DevOps pipeline (CI/CD)
- README.md

## Local build & run (docker)
1. Build locally:
   docker build -t eshop:local -f Dockerfile .
2. Run:
   docker run -p 8080:80 eshop:local
3. Open Swagger:
   http://localhost:8080/swagger

## Push to Azure Container Registry (ACR)
1. Create resource group, ACR and AKS (if you don't have them):
   az group create -n myResourceGroup -l eastus
   az acr create -n <YOUR_ACR_NAME> -g myResourceGroup --sku Standard
   az aks create -n <YOUR_AKS_CLUSTER_NAME> -g myResourceGroup --node-count 2 --generate-ssh-keys --attach-acr <YOUR_ACR_NAME>

2. Build, tag and push:
   ACR_NAME=<YOUR_ACR_NAME>
   docker build -t $ACR_NAME.azurecr.io/eshop:latest -f Dockerfile .
   az acr login --name $ACR_NAME
   docker push $ACR_NAME.azurecr.io/eshop:latest

3. Edit k8s/deployment.yaml: replace image with:
   <YOUR_ACR_NAME>.azurecr.io/eshop:latest

4. Deploy to AKS:
   az aks get-credentials -g <resource-group> -n <cluster-name>
   kubectl apply -f k8s/deployment.yaml
   kubectl apply -f k8s/service.yaml
   kubectl get svc eshop-service
   # Wait for external IP to appear and access it on port 80.

## Azure DevOps pipeline
Update `azure-pipelines.yml`:
- Replace `<YOUR_AZURE_SERVICE_CONNECTION>` with a service connection that has contributor access to your subscription.
- Replace `<YOUR_ACR_NAME>`, `<YOUR_AKS_RESOURCE_GROUP>`, `<YOUR_AKS_CLUSTER_NAME>` in the pipeline script.

## Notes / Testing
- The API exposes:
  GET /api/products
  GET /api/products/{id}
  POST /api/products
  PUT /api/products/{id}
  DELETE /api/products/{id}
- Swagger is available at `/swagger`.
